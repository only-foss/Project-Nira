# Changelog — Project Nira

All notable changes to this project are documented here.
Format: [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)

---

## [v1.0] — 2026-03-22 — First Validated Prototype

### Added
- ESP32 + FDC1004 breadboard prototype hardware
- Arduino firmware for capacitance sampling (CH1, CH4, diff_c1_c4)
- InfluxDB data logging over WiFi
- Grafana dashboard for real-time visualisation
- Test dataset: clean water vs. water with microplastics (97 total samples)
- GNU Octave analysis suite (`nira_analysis.m` + 4 plot functions)
- 4 validated output plots: time-series, comparison, histogram, scatter
- KiCad schematic and PCB layout (v1.0)
- CERN-OHL-P hardware license
- Project PDF overview document

### Validated Results
| Metric | Value |
|--------|-------|
| Clean water mean diff_c1_c4 | −193.6 ADC |
| Microplastic water mean diff_c1_c4 | +377.8 ADC |
| Detection shift | +571 ADC (4.4 sigma above clean baseline) |
| p-value (Welch t-test) | 3.24×10⁻⁴⁵ (p < 0.001) |
| Suggested detection threshold | diff_c1_c4 > 92 ADC units |

---

## [Unreleased] — In Progress

### Planned for v1.1
- [ ] PCB design replacing breadboard (KiCad)
- [ ] Gerber files exported to `hardware/v1.1/pcb/`
- [ ] `BOM.csv` with full component sourcing
- [ ] `WIRING_NOTES.md` + draw.io wiring diagram
- [ ] `CONTRIBUTING.md` and `CITATION.cff`
- [ ] `python/nira_reader.py` InfluxDB export utility
- [ ] OSHWA certification submission

### Planned for v2.0
- [ ] ESP32-S3 + ADS131M08 24-bit ADC upgrade
- [ ] IP67 waterproof enclosure
- [ ] BLE/WiFi configuration portal
- [ ] On-device ML-based classification
- [ ] Flow-through sample chamber design
